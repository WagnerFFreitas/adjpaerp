import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Save, Upload, User, Heart, Cross, BookOpen } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function MembroForm() {
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    setTimeout(() => {
      setIsLoading(false);
      navigate("/igreja/membros");
    }, 1000);
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <div>
          <h1 className="page-title">Novo Membro</h1>
          <p className="page-subtitle">Cadastre um novo membro da igreja</p>
        </div>
      </div>

      <form onSubmit={handleSubmit}>
        <Tabs defaultValue="pessoal" className="space-y-6">
          <TabsList className="bg-muted/50 p-1">
            <TabsTrigger value="pessoal">Dados Pessoais</TabsTrigger>
            <TabsTrigger value="vidacrista">Vida Cristã</TabsTrigger>
            <TabsTrigger value="ministerio">Ministérios</TabsTrigger>
            <TabsTrigger value="endereco">Endereço</TabsTrigger>
            <TabsTrigger value="observacoes">Observações</TabsTrigger>
          </TabsList>

          {/* Dados Pessoais */}
          <TabsContent value="pessoal" className="space-y-6">
            <div className="card-elevated p-6">
              <div className="flex items-start gap-6 mb-6">
                <div className="w-32 h-32 rounded-xl bg-muted flex flex-col items-center justify-center border-2 border-dashed border-border cursor-pointer hover:border-secondary transition-colors">
                  <User className="w-10 h-10 text-muted-foreground mb-2" />
                  <span className="text-xs text-muted-foreground">Upload Foto</span>
                </div>
                <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="nome">Nome Completo *</Label>
                    <Input id="nome" placeholder="Nome completo" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="dataNascimento">Data de Nascimento *</Label>
                    <Input id="dataNascimento" type="date" required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="cpf">CPF</Label>
                    <Input id="cpf" placeholder="000.000.000-00" />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="rg">RG</Label>
                    <Input id="rg" placeholder="Número do RG" />
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="sexo">Sexo *</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="M">Masculino</SelectItem>
                      <SelectItem value="F">Feminino</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="estadoCivil">Estado Civil</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="solteiro">Solteiro(a)</SelectItem>
                      <SelectItem value="casado">Casado(a)</SelectItem>
                      <SelectItem value="divorciado">Divorciado(a)</SelectItem>
                      <SelectItem value="viuvo">Viúvo(a)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="profissao">Profissão</Label>
                  <Input id="profissao" placeholder="Profissão" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="email">E-mail</Label>
                  <Input id="email" type="email" placeholder="email@exemplo.com" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="telefone">Telefone *</Label>
                  <Input id="telefone" placeholder="(00) 00000-0000" required />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="celular">WhatsApp</Label>
                  <Input id="celular" placeholder="(00) 00000-0000" />
                </div>
              </div>
            </div>
          </TabsContent>

          {/* Vida Cristã */}
          <TabsContent value="vidacrista" className="space-y-6">
            <div className="card-elevated p-6">
              <h3 className="font-semibold mb-4 flex items-center gap-2">
                <Cross className="w-5 h-5 text-secondary" />
                Conversão e Batismo
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="dataConversao">Data de Conversão</Label>
                  <Input id="dataConversao" type="date" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="localConversao">Local da Conversão</Label>
                  <Input id="localConversao" placeholder="Igreja, campanha, etc." />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="dataBatismoAguas">Data do Batismo nas Águas</Label>
                  <Input id="dataBatismoAguas" type="date" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="igrejaBatismo">Igreja do Batismo</Label>
                  <Input id="igrejaBatismo" placeholder="Nome da igreja" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="pastorBatismo">Pastor que Batizou</Label>
                  <Input id="pastorBatismo" placeholder="Nome do pastor" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="batismoEspiritoSanto">Batismo no Espírito Santo</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="sim">Sim</SelectItem>
                      <SelectItem value="nao">Não</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            <div className="card-elevated p-6">
              <h3 className="font-semibold mb-4 flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-secondary" />
                Formação e Status
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="status">Status do Membro *</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ativo">Ativo</SelectItem>
                      <SelectItem value="congregado">Congregado</SelectItem>
                      <SelectItem value="afastado">Afastado</SelectItem>
                      <SelectItem value="transferido">Transferido</SelectItem>
                      <SelectItem value="desligado">Desligado</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="dataMembresia">Data de Membresia</Label>
                  <Input id="dataMembresia" type="date" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="igrejaOrigem">Igreja de Origem</Label>
                  <Input id="igrejaOrigem" placeholder="Se veio de outra igreja" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="cursoDiscipulado">Curso de Discipulado</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="concluido">Concluído</SelectItem>
                      <SelectItem value="cursando">Cursando</SelectItem>
                      <SelectItem value="nao">Não realizou</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="escolaBiblica">Escola Bíblica</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="frequenta">Frequenta</SelectItem>
                      <SelectItem value="nao">Não frequenta</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            <div className="card-elevated p-6">
              <h3 className="font-semibold mb-4 flex items-center gap-2">
                <Heart className="w-5 h-5 text-secondary" />
                Contribuições
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="flex items-center space-x-2">
                  <Checkbox id="dizimista" />
                  <Label htmlFor="dizimista">Dizimista</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox id="ofertante" />
                  <Label htmlFor="ofertante">Ofertante Regular</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <Checkbox id="campanha" />
                  <Label htmlFor="campanha">Participa de Campanhas</Label>
                </div>
              </div>
            </div>
          </TabsContent>

          {/* Ministérios */}
          <TabsContent value="ministerio" className="space-y-6">
            <div className="card-elevated p-6">
              <h3 className="font-semibold mb-4">Participação nos Ministérios</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="ministerioPrincipal">Ministério Principal</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="louvor">Louvor e Adoração</SelectItem>
                      <SelectItem value="infantil">Infantil</SelectItem>
                      <SelectItem value="jovens">Jovens</SelectItem>
                      <SelectItem value="casais">Casais</SelectItem>
                      <SelectItem value="intercessao">Intercessão</SelectItem>
                      <SelectItem value="recepcao">Recepção</SelectItem>
                      <SelectItem value="midia">Mídia</SelectItem>
                      <SelectItem value="diaconia">Diaconia</SelectItem>
                      <SelectItem value="evangelismo">Evangelismo</SelectItem>
                      <SelectItem value="missoes">Missões</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="cargoMinisterio">Cargo no Ministério</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="lider">Líder</SelectItem>
                      <SelectItem value="colider">Co-líder</SelectItem>
                      <SelectItem value="auxiliar">Auxiliar</SelectItem>
                      <SelectItem value="membro">Membro</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="mt-6">
                <Label className="mb-2 block">Outros Ministérios</Label>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                  {["Louvor", "Infantil", "Jovens", "Casais", "Intercessão", "Recepção", "Mídia", "Diaconia", "Evangelismo", "Missões", "Teatro", "Dança"].map((min) => (
                    <div key={min} className="flex items-center space-x-2">
                      <Checkbox id={min.toLowerCase()} />
                      <Label htmlFor={min.toLowerCase()} className="text-sm">{min}</Label>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            <div className="card-elevated p-6">
              <h3 className="font-semibold mb-4">Cargos Eclesiásticos</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="cargoEclesiastico">Cargo Eclesiástico</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="nenhum">Nenhum</SelectItem>
                      <SelectItem value="obreiro">Obreiro(a)</SelectItem>
                      <SelectItem value="diacono">Diácono(a)</SelectItem>
                      <SelectItem value="presbitero">Presbítero(a)</SelectItem>
                      <SelectItem value="evangelista">Evangelista</SelectItem>
                      <SelectItem value="missionario">Missionário(a)</SelectItem>
                      <SelectItem value="pastor">Pastor(a)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="dataConsagracao">Data de Consagração</Label>
                  <Input id="dataConsagracao" type="date" />
                </div>
              </div>
            </div>
          </TabsContent>

          {/* Endereço */}
          <TabsContent value="endereco" className="space-y-6">
            <div className="card-elevated p-6">
              <h3 className="font-semibold mb-4">Endereço Residencial</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="cep">CEP</Label>
                  <Input id="cep" placeholder="00000-000" />
                </div>
                <div className="space-y-2 md:col-span-2">
                  <Label htmlFor="logradouro">Logradouro</Label>
                  <Input id="logradouro" placeholder="Rua, Avenida, etc." />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="numero">Número</Label>
                  <Input id="numero" placeholder="Número" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="complemento">Complemento</Label>
                  <Input id="complemento" placeholder="Apto, Bloco, etc." />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="bairro">Bairro</Label>
                  <Input id="bairro" placeholder="Bairro" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="cidade">Cidade</Label>
                  <Input id="cidade" placeholder="Cidade" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="estado">Estado</Label>
                  <Select>
                    <SelectTrigger>
                      <SelectValue placeholder="Selecione" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="AC">Acre</SelectItem>
                      <SelectItem value="AL">Alagoas</SelectItem>
                      <SelectItem value="AP">Amapá</SelectItem>
                      <SelectItem value="AM">Amazonas</SelectItem>
                      <SelectItem value="BA">Bahia</SelectItem>
                      <SelectItem value="CE">Ceará</SelectItem>
                      <SelectItem value="DF">Distrito Federal</SelectItem>
                      <SelectItem value="ES">Espírito Santo</SelectItem>
                      <SelectItem value="GO">Goiás</SelectItem>
                      <SelectItem value="MA">Maranhão</SelectItem>
                      <SelectItem value="MT">Mato Grosso</SelectItem>
                      <SelectItem value="MS">Mato Grosso do Sul</SelectItem>
                      <SelectItem value="MG">Minas Gerais</SelectItem>
                      <SelectItem value="PA">Pará</SelectItem>
                      <SelectItem value="PB">Paraíba</SelectItem>
                      <SelectItem value="PR">Paraná</SelectItem>
                      <SelectItem value="PE">Pernambuco</SelectItem>
                      <SelectItem value="PI">Piauí</SelectItem>
                      <SelectItem value="RJ">Rio de Janeiro</SelectItem>
                      <SelectItem value="RN">Rio Grande do Norte</SelectItem>
                      <SelectItem value="RS">Rio Grande do Sul</SelectItem>
                      <SelectItem value="RO">Rondônia</SelectItem>
                      <SelectItem value="RR">Roraima</SelectItem>
                      <SelectItem value="SC">Santa Catarina</SelectItem>
                      <SelectItem value="SP">São Paulo</SelectItem>
                      <SelectItem value="SE">Sergipe</SelectItem>
                      <SelectItem value="TO">Tocantins</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
          </TabsContent>

          {/* Observações */}
          <TabsContent value="observacoes" className="space-y-6">
            <div className="card-elevated p-6">
              <h3 className="font-semibold mb-4">Observações e Anotações</h3>
              <div className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="observacoes">Observações Gerais</Label>
                  <Textarea
                    id="observacoes"
                    placeholder="Informações adicionais sobre o membro..."
                    rows={4}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="necessidades">Necessidades Especiais</Label>
                  <Textarea
                    id="necessidades"
                    placeholder="Necessidades especiais, restrições, etc."
                    rows={3}
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="talentos">Talentos e Habilidades</Label>
                  <Textarea
                    id="talentos"
                    placeholder="Talentos, habilidades profissionais que podem contribuir..."
                    rows={3}
                  />
                </div>
              </div>
            </div>
          </TabsContent>

          {/* Actions */}
          <div className="flex justify-end gap-4 pt-6 border-t">
            <Button type="button" variant="outline" onClick={() => navigate(-1)}>
              Cancelar
            </Button>
            <Button type="submit" variant="gold" disabled={isLoading}>
              {isLoading ? (
                <>Salvando...</>
              ) : (
                <>
                  <Save className="w-4 h-4" />
                  Salvar Membro
                </>
              )}
            </Button>
          </div>
        </Tabs>
      </form>
    </div>
  );
}
