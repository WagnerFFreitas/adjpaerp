import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/client';
import { AppRole, Profile, Unit } from '@/types/database';

interface AuthContextType {
  user: User | null;
  session: Session | null;
  profile: Profile | null;
  roles: AppRole[];
  currentUnit: Unit | null;
  units: Unit[];
  loading: boolean;
  signIn: (email: string, password: string) => Promise<{ error: Error | null }>;
  signInWithUsername: (username: string, password: string) => Promise<{ error: Error | null }>;
  signUp: (email: string, password: string, name: string, username: string) => Promise<{ error: Error | null }>;
  signOut: () => Promise<void>;
  hasRole: (role: AppRole) => boolean;
  hasAnyRole: (roles: AppRole[]) => boolean;
  setCurrentUnit: (unit: Unit) => void;
  refreshProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [roles, setRoles] = useState<AppRole[]>([]);
  const [currentUnit, setCurrentUnitState] = useState<Unit | null>(null);
  const [units, setUnits] = useState<Unit[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchProfile = useCallback(async (userId: string) => {
    try {
      const { data: profileData, error: profileError } = await supabase
        .from('profiles')
        .select('*')
        .eq('user_id', userId)
        .single();

      if (profileError) {
        console.error('Error fetching profile:', profileError);
        return;
      }

      setProfile(profileData as Profile);

      // Fetch user roles
      const { data: rolesData, error: rolesError } = await supabase
        .from('user_roles')
        .select('role')
        .eq('user_id', userId);

      if (rolesError) {
        console.error('Error fetching roles:', rolesError);
      } else {
        setRoles((rolesData || []).map(r => r.role as AppRole));
      }

      // Fetch available units
      const { data: unitsData, error: unitsError } = await supabase
        .from('units')
        .select('*')
        .order('name');

      if (unitsError) {
        console.error('Error fetching units:', unitsError);
      } else {
        setUnits(unitsData as Unit[]);
        
        // Set default unit
        if (unitsData && unitsData.length > 0) {
          const defaultUnit = profileData?.default_unit_id 
            ? unitsData.find((u: Unit) => u.id === profileData.default_unit_id)
            : unitsData.find((u: Unit) => u.is_headquarter) || unitsData[0];
          
          if (defaultUnit) {
            setCurrentUnitState(defaultUnit as Unit);
          }
        }
      }
    } catch (error) {
      console.error('Error in fetchProfile:', error);
    }
  }, []);

  const refreshProfile = useCallback(async () => {
    if (user) {
      await fetchProfile(user.id);
    }
  }, [user, fetchProfile]);

  useEffect(() => {
    // Set up auth state listener FIRST
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        setSession(session);
        setUser(session?.user ?? null);
        
        if (session?.user) {
          // Use setTimeout to avoid race conditions
          setTimeout(() => {
            fetchProfile(session.user.id);
          }, 0);
        } else {
          setProfile(null);
          setRoles([]);
          setCurrentUnitState(null);
        }
        
        setLoading(false);
      }
    );

    // THEN check for existing session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      
      if (session?.user) {
        fetchProfile(session.user.id);
      }
      
      setLoading(false);
    });

    return () => {
      subscription.unsubscribe();
    };
  }, [fetchProfile]);

  const signIn = async (email: string, password: string) => {
    try {
      const { error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });
      return { error };
    } catch (error) {
      return { error: error as Error };
    }
  };

  const signInWithUsername = async (username: string, password: string) => {
    try {
      // Look up the email by username using the database function
      const { data: email, error: lookupError } = await supabase
        .rpc('get_email_by_username', { p_username: username });

      if (lookupError || !email) {
        return { error: new Error('User not found') };
      }

      return await signIn(email, password);
    } catch (error) {
      return { error: error as Error };
    }
  };

  const signUp = async (email: string, password: string, name: string, username: string) => {
    try {
      const { error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          emailRedirectTo: window.location.origin,
          data: {
            name,
            username: username.toLowerCase(),
          },
        },
      });
      return { error };
    } catch (error) {
      return { error: error as Error };
    }
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    setProfile(null);
    setRoles([]);
    setCurrentUnitState(null);
  };

  const hasRole = useCallback((role: AppRole) => {
    return roles.includes(role) || roles.includes('admin');
  }, [roles]);

  const hasAnyRole = useCallback((checkRoles: AppRole[]) => {
    return roles.includes('admin') || checkRoles.some(role => roles.includes(role));
  }, [roles]);

  const setCurrentUnit = useCallback((unit: Unit) => {
    setCurrentUnitState(unit);
    
    // Update default unit in profile
    if (profile) {
      supabase
        .from('profiles')
        .update({ default_unit_id: unit.id })
        .eq('id', profile.id)
        .then(({ error }) => {
          if (error) console.error('Error updating default unit:', error);
        });
    }
  }, [profile]);

  const value = {
    user,
    session,
    profile,
    roles,
    currentUnit,
    units,
    loading,
    signIn,
    signInWithUsername,
    signUp,
    signOut,
    hasRole,
    hasAnyRole,
    setCurrentUnit,
    refreshProfile,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
